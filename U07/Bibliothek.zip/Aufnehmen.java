import java.util.List;

public interface Aufnehmen {
    public void neuesBuch(List<Buch> liste, Buch buch);
}
